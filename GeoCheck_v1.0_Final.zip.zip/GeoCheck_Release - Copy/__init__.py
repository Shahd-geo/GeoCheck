
def classFactory(iface):
    from .geocheck_plugin import GeoCheckPlugin
    return GeoCheckPlugin(iface)
